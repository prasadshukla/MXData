package com.mx.test;

import java.util.List;

import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.mx.beans.BeanToXmlConverter;
import com.mx.beans.MXDataBean;
import com.mx.dao.MxDao;

public class TestData {
	
	public static void main(String args[]) {
	
		 ApplicationContext ctx=new ClassPathXmlApplicationContext("com/mx/resource/application-context.xml");  
	      
		    MxDao mXDao=(MxDao)ctx.getBean("mXDao");  
		    List<MXDataBean> mxData= mXDao.getData();
		    System.out.println(mxData);
		    BeanToXmlConverter BTXConverter=(BeanToXmlConverter)ctx.getBean("BTXConverter");
		    BTXConverter.convert(mxData);
		    
	}

}
