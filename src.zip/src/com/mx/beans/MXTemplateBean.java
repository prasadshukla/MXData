package com.mx.beans;

public class MXTemplateBean {

	private String rootNode;
	private String childNode;
	private String endRootNode;

	public String getRootNode() {
		return rootNode;
	}

	public void setRootNode(String rootNode) {
		this.rootNode = rootNode;
	}

	public String getChildNode() {
		return childNode;
	}

	public void setChildNode(String childNode) {
		this.childNode = childNode;
	}

	public String getEndRootNode() {
		return endRootNode;
	}

	public void setEndRootNode(String endRootNode) {
		this.endRootNode = endRootNode;
	}

}
