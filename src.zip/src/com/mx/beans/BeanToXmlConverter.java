package com.mx.beans;

import java.util.List;

public class BeanToXmlConverter {
	
	private MXTemplateBean mxTemplateBean;
	
	public BeanToXmlConverter(MXTemplateBean mxTemplateBean) {
		this.mxTemplateBean = mxTemplateBean;
	}

	public void convert(List<MXDataBean> mxData) {
		
		String xmlData="";
		String phaseData1="";
		String phaseData2="";
	 
		
		xmlData=mxTemplateBean.getRootNode();
		
		for(int i=0;i<mxData.size();i++) {
			
			phaseData1=mxData.get(i).getFname();
			phaseData2=mxData.get(i).getLname();
			String phase1=mxTemplateBean.getChildNode().replace("@@firstname@@",phaseData1);
			String phase2=phase1.replace("@@lastname@@",phaseData2);
			xmlData=xmlData+phase2;
		}
		xmlData=xmlData+mxTemplateBean.getRootNode();
		System.out.println(xmlData);
	}

}
