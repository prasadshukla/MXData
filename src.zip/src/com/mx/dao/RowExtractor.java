package com.mx.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.ResultSetExtractor;

import com.mx.beans.MXDataBean;

final class RowExtractor implements ResultSetExtractor{

	@Override
	public List<MXDataBean> extractData(ResultSet rs) throws SQLException {
		List<MXDataBean> mxData =new ArrayList<>();
		while (rs.next()) {
			MXDataBean mxDataBean=new MXDataBean();
			mxDataBean.setFname(rs.getString("fname"));
			mxDataBean.setLname(rs.getString("lname"));
			mxData.add(mxDataBean);
		}
		return mxData;
	}
}
