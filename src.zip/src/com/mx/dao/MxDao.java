package com.mx.dao;

import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;

import com.mx.beans.MXDataBean;

public class MxDao {
	private JdbcTemplate jdbcTemplate;

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public List getData(){  
		List<MXDataBean> mxData = (List<MXDataBean>) jdbcTemplate.query("SELECT fname, lname FROM test1.Student", new RowExtractor());
		return mxData;
	}

	

}
